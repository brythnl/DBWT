<?php
    
include ('m2_4a_standardparameter.php');
echo '1 + 1 = ' . addieren(1, 1) . '<br>';
echo '2 + 2 = ' . addieren(2, 2) . '<br>';
echo '3 + 3 = ' . addieren(3, 3) . '<br>';

?>