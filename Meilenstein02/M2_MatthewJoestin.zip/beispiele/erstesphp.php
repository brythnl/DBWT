<?php
echo "Erstes PHP Skript <br>";
phpinfo();