<?php

function addieren($a = 0, $b = 0) {
    return $a + $b;
}

?>