<?php

$Gericht = [
    'wok' => [ 'name' => 'Rindfleisch mit Bambus, Kaiserschoten und Rotem Paprika, dazu Mie Nudeln', 
               'bild' => '<img class="gericht-img" src="./images/wok.jpg" alt="wok">'],
    'vegetarisch' => [ 'name' => 'Spinatrisotto mit kleinen Samosateigecken und gemischter Salat', 
                       'bild' => '<img class="gericht-img" src="./images/veg.jpg" alt="vegetarisch">'],
    'klassiker' => [ 'name' => 'Schweineschnitzel mit Pommes', 
                     'bild' => '<img class="gericht-img" src="./images/klassik.jpg" alt="klassiker">'],
    'tellergericht' => [ 'name' => 'Lauch-Käse-Suppe mit Kartoffel und Rinderhack', 
                         'bild' => '<img class="gericht-img" src="./images/teller.jpg" alt="tellergericht">']
]

?>